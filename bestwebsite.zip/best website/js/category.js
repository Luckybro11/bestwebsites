// Render websites
const webList = document.getElementById('webList');
websites.forEach((site,index)=>{
  const div = document.createElement('div');
  div.className="website-card";
  div.innerHTML=`
    <a href="${site.url}" target="_blank"><strong>${site.name}</strong></a>
    <p>${site.detail}</p>
    <div class="stars">
      ${[1,2,3,4,5].map(i=>`<span class="star" data-index="${i}" data-site="${index}">&#9733;</span>`).join('')}
    </div>
    <div class="avg-rating">Average Rating: <span id="avg-${index}">0</span>/5</div>
    <button class="addFav" data-index="${index}">Add to Favorites</button>
    <button class="feedbackBtn" data-index="${index}">Feedback</button>
  `;
  webList.appendChild(div);
});

// Load ratings from localStorage
let ratings = JSON.parse(localStorage.getItem('webRatings')) || {};

// Function to calculate average rating
function avg(arr){return arr.length? (arr.reduce((a,b)=>a+b,0)/arr.length).toFixed(1) : 0;}

// Set initial star selections
document.querySelectorAll('.website-card').forEach((card,i)=>{
  const stars = card.querySelectorAll('.star');
  const saved = ratings[i] || [];
  card.querySelector(`#avg-${i}`).textContent = avg(saved);
  stars.forEach(star=>{
    if(star.dataset.index <= Math.round(avg(saved))) star.classList.add('selected');
    star.addEventListener('click', ()=>{
      const val = Number(star.dataset.index);
      if(!ratings[i]) ratings[i]=[];
      ratings[i].push(val);
      localStorage.setItem('webRatings', JSON.stringify(ratings));
      card.querySelector(`#avg-${i}`).textContent = avg(ratings[i]);
      stars.forEach(s=>s.classList.remove('selected'));
      stars.forEach(s=>{ if(s.dataset.index <= Math.round(avg(ratings[i]))) s.classList.add('selected'); });
    });
  });
});

// Favorites
document.querySelectorAll('.addFav').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    const idx = btn.dataset.index;
    let favs = JSON.parse(localStorage.getItem('bestWebsiteFavorites')) || [];
    const site = websites[idx];
    if(!favs.some(f=>f.name===site.name)){
      favs.push(site);
      localStorage.setItem('bestWebsiteFavorites', JSON.stringify(favs));
      alert(`${site.name} added to favorites`);
    }else alert(`${site.name} is already in favorites`);
  });
});

// Feedback
document.querySelectorAll('.feedbackBtn').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    const idx = btn.dataset.index;
    const feedback = prompt(`Provide feedback for ${websites[idx].name}:`);
    if(feedback) alert("Thank you for your feedback!");
  });
});