 
    const toggleAll = document.getElementById('toggleAll');
    let shown = false;

    toggleAll.addEventListener('click', ()=>{
      shown = !shown;
      document.querySelectorAll('.web').forEach(q=>{
        if(shown) q.classList.add('show');
        else q.classList.remove('show');
      });
      toggleAll.textContent = shown ? 'Hide' : 'Show';
    });

    document.getElementById('printBtn').addEventListener('click', ()=> window.print());

    // Individual toggle on double-click
    document.querySelectorAll('.web').forEach(q=>{
      q.addEventListener('dblclick', ()=> q.classList.toggle('show'));
    });
 